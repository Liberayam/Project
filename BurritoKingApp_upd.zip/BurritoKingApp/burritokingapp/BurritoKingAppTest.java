/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package burritokingapp;

import javafx.stage.Stage;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class BurritoKingAppTest {
    
    public BurritoKingAppTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testLoginWithValidCredentials() {
        String username="sam";
        String password="jack";
        boolean expResult = false;
        boolean result = false;
        if (username.isEmpty() || password.isEmpty()) {
           result=true;
        }

        
      
        assertEquals(expResult, result);
       
    }

    
  

    @Test
    public void testLoginWithInvalidCredentials() {
        String username="sam";
        String password="jack";
        boolean expResult = true;
        boolean result = false;
        if (username.equals("sam") || password.equals("jack")) {
           result=true;
        }

        
      
        assertEquals(expResult, result);
    }

    
    
}
