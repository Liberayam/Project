/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package burritokingapp;



public class FoodItem {
    private String Foodname;
    private double Foodprice;

    public FoodItem(String Foodname, double Foodprice) {
        this.Foodname = Foodname;
        this.Foodprice = Foodprice;
    }

    public String getFoodName() {
        return Foodname;
    }

    public double getFoodPrice() {
        return Foodprice;
    }

    @Override
    public String toString() {
        return Foodname + " - $" + Foodprice;
    }
}
