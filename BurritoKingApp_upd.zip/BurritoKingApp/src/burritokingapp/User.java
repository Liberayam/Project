import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class User {
    private String Cust_username;
    private String Cust_password;
    private String Cust_firstName;
    private String Cust_lastName;
    private boolean custisVIP;
    private String custemail;
    private int custcredits;

    private static Map<String, User> UserColl = new HashMap<>();
    private static final String DBFile = "auth.csv";

    public User(String Cust_username, String Cust_password, String Cust_firstName, String Cust_lastName) {
        this.Cust_username = Cust_username;
        this.Cust_password = Cust_password;
        this.Cust_firstName = Cust_firstName;
        this.Cust_lastName = Cust_lastName;
        this.custisVIP = false;
        this.custcredits = 0;
        UserColl.put(Cust_username, this);
        saveCustUsersToFile();
    }

    public static User getCustUser(String username) {
        return UserColl.get(username);
    }

    public boolean CustcheckPassword(String password) {
        return this.Cust_password.equals(password);
    }

    public void CustupgradeToVIP(String email) {
        this.custisVIP = true;
        this.custemail = email;
        saveCustUsersToFile();
    }

    public boolean CustisVIP() {
        return custisVIP;
    }

    public void CustaddCredits(int amount) {
        this.custcredits += amount;
        saveCustUsersToFile();
    }

    public int getCustCredits() {
        return custcredits;
    }

    public void CustredeemCredits(int amount) {
        if (amount <= custcredits) {
            custcredits -= amount;
        }
        saveCustUsersToFile();
    }

    public String getCustFirstName() {
        return Cust_firstName;
    }

    public void setCustFirstName(String firstName) {
        this.Cust_firstName = firstName;
        saveCustUsersToFile();
    }

    public String getCustLastName() {
        return Cust_lastName;
    }

    public void setCustLastName(String lastName) {
        this.Cust_lastName = lastName;
        saveCustUsersToFile();
    }

    public String getCustUsername() {
        return Cust_username;
    }

    public void setCustPassword(String password) {
        this.Cust_password = password;
        saveCustUsersToFile();
    }

    public static void loadCustUsersFromFile() {
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(DBFile))) {
            String record;
            while ((record = bufferedReader.readLine()) != null) {
                String[] recordDetails = record.split(",");
                if (recordDetails.length == 7) {
                    User user = new User(recordDetails[0], recordDetails[1], recordDetails[2], recordDetails[3]);
                    user.custisVIP = Boolean.parseBoolean(recordDetails[4]);
                    user.custemail = recordDetails[5];
                    user.custcredits = Integer.parseInt(recordDetails[6]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveCustUsersToFile() {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(DBFile))) {
            for (User user : UserColl.values()) {
                bufferedWriter.write(user.Cust_username + "," + user.Cust_password + "," + user.Cust_firstName + "," + user.Cust_lastName + ","
                        + user.custisVIP + "," + user.custemail + "," + user.custcredits);
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
