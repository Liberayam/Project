package burritokingapp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Order {
    private LocalDateTime dateTime;
    private LocalDateTime collectTime;
    private List<FoodItem> items;
    private String status;
  
    private double totalPrice;
    private static final String FILE_PATH = "orders.csv";

    public Order(List<FoodItem> items, String status) {
        this.dateTime = LocalDateTime.now();
        this.items = items;
        this.status = status;
        this.collectTime = null;
        OrderSavetoDB();
    }
    


    public Order(List<FoodItem> items, String status, double totalPrice) {
        this.items = items;
        this.status = status;
        this.dateTime = LocalDateTime.now();
        this.totalPrice = totalPrice;
    }

  
    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public LocalDateTime getCollectTime() {
        return collectTime;
    }

   
    /*public String getFormattedDateTime() {
        return dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    public String getFormattedCollectTime() {
        return collectTime != null ? collectTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : "N/A";
    }
*/
  
    public double getOrderTotalPrice() {
        return items.stream().mapToDouble(FoodItem::getFoodPrice).sum();
    }

    public String getOrderStatus() {
        return status;
    }

    public void setOrderStatus(String status) {
        this.status = status;
        OrderSavetoDB();
    }

    public void setCollectTime(LocalDateTime collectTime) {
        this.collectTime = collectTime;
        OrderSavetoDB();
    }

    public String getFormattedDateTime() {
        DateTimeFormatter dfm = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return dateTime.format(dfm);
    }

    public String getFormattedCollectTime() {
        if (collectTime == null) {
            return "Not collected";
        }
        DateTimeFormatter dfm = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return collectTime.format(dfm);
    }

    public List<FoodItem> getItems() {
        return items;
    }

    private void OrderSavetoDB() {
        try (BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            bufferedwriter.write(toCSV());
            bufferedwriter.newLine();
        } catch (IOException e) {
            System.err.println("Error writing to orders file: " + e.getMessage());
        }
    }

    private String toCSV() {
        StringBuilder itemsString = new StringBuilder();
        for (FoodItem item : items) {
            itemsString.append(item.getFoodName()).append(" (").append(item.getFoodPrice()).append("), ");
        }
        // Remove trailing comma and space
        if (itemsString.length() > 0) {
            itemsString.setLength(itemsString.length() - 2);
        }

        return getFormattedDateTime() + "," + itemsString.toString() + "," + getOrderTotalPrice() + "," + status + "," + getFormattedCollectTime();
    }
}
