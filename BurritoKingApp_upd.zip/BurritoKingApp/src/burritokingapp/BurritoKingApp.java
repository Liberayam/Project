package burritokingapp;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BurritoKingApp extends Application {

    private Stage ps;
    private List<FoodItem> shoppingBasket = new ArrayList<>();
    private List<Order> ordersList = new ArrayList<>();
    private Label lblbasket = new Label();

    @Override
    public void start(Stage ps) {
        this.ps = ps;
        User.loadCustUsersFromFile();
        getLoginForm();
    }

    private void getLoginForm() {
        ps.setTitle("Burrito King Login");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        Label usernamelbl = new Label("Username:");
        TextField usernameInput = new TextField();
        Label passwordlbl = new Label("Password:");
        PasswordField passwordInput = new PasswordField();
        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");

        oGridPane.add(usernamelbl, 0, 0);
        oGridPane.add(usernameInput, 1, 0);
        oGridPane.add(passwordlbl, 0, 1);
        oGridPane.add(passwordInput, 1, 1);
        oGridPane.add(loginButton, 1, 2);
        oGridPane.add(registerButton, 1, 3);

        loginButton.setOnAction(e -> handleLogin(usernameInput.getText(), passwordInput.getText()));
        registerButton.setOnAction(e -> getRegistrationForm());

        Scene loginScene = new Scene(oGridPane, 300, 200);
        ps.setScene(loginScene);
        ps.show();
    }

    private void handleLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            Message("Validation Error", "Username and password cannot be empty.");
            return;
        }

        User user = User.getCustUser(username);
        if (user != null && user.CustcheckPassword(password)) {
            getDashboard(user);
        } else {
            Message("Login Failed", "Incorrect username or password.");
        }
    }

    
    private void getRegistrationForm() {
        ps.setTitle("Burrito King Registration");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        Label usernamelbl = new Label("Username:");
        TextField usernameInput = new TextField();
        Label passwordlbl = new Label("Password:");
        PasswordField passwordInput = new PasswordField();
        Label firstNamelbl = new Label("First Name:");
        TextField firstNameInput = new TextField();
        Label lastNamelbl = new Label("Last Name:");
        TextField lastNameInput = new TextField();
        Button submitButton = new Button("Submit");
        Button backButton = new Button("Back");

        oGridPane.add(usernamelbl, 0, 0);
        oGridPane.add(usernameInput, 1, 0);
        oGridPane.add(passwordlbl, 0, 1);
        oGridPane.add(passwordInput, 1, 1);
        oGridPane.add(firstNamelbl, 0, 2);
        oGridPane.add(firstNameInput, 1, 2);
        oGridPane.add(lastNamelbl, 0, 3);
        oGridPane.add(lastNameInput, 1, 3);
        oGridPane.add(submitButton, 1, 4);
        oGridPane.add(backButton, 0, 4);

        submitButton.setOnAction(e -> handleRegistration(usernameInput.getText(), passwordInput.getText(), firstNameInput.getText(), lastNameInput.getText()));
        backButton.setOnAction(e -> getLoginForm());

        Scene registrationScene = new Scene(oGridPane, 300, 250);
        ps.setScene(registrationScene);
    }
    private void handleRegistration(String username, String password, String firstName, String lastName) {
        if (username.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
            Message("Validation Error", "All fields are required.");
            return;
        }

        if (User.getCustUser(username) == null) {
            new User(username, password, firstName, lastName);
            Message("Registration Successful", "User registered successfully. You can now log in.");
            getLoginForm();
        } else {
            Message("Registration Failed", "Username already exists.");
        }
    }

    private void getDashboard(User user) {
        ps.setTitle("Burrito King Dashboard");

        VBox ovbox = new VBox(10);
        ovbox.setPadding(new Insets(25, 25, 25, 25));
        ovbox.setAlignment(Pos.CENTER);

        Label welcomelbl = new Label("Welcome, " + user.getCustFirstName() + " " + user.getCustLastName());
        Button editProfileButton = new Button("Edit Profile");
        Button orderButton = new Button(user.CustisVIP() ? "Place VIP Order" : "Place Order");
        Button viewOrdersButton = new Button("View Orders");
        Button exportOrdersButton = new Button("Export Orders");
        Button vipUpgradeButton = new Button("Upgrade to VIP");
        Button logoutButton = new Button("Logout");

        editProfileButton.setOnAction(e -> getEditProfile(user));
        orderButton.setOnAction(e -> getPlaceOrder(user));
        viewOrdersButton.setOnAction(e -> getViewOrders(user));
        exportOrdersButton.setOnAction(e -> getExportOrders(user));
        vipUpgradeButton.setOnAction(e -> getVIPUpgrade(user));
        logoutButton.setOnAction(e -> getLoginForm());

        ovbox.getChildren().addAll(welcomelbl, editProfileButton, orderButton, viewOrdersButton, exportOrdersButton, vipUpgradeButton, logoutButton);

        ps.setScene(new Scene(ovbox, 400, 300));
    }

    private void getEditProfile(User user) {
        ps.setTitle("Edit Profile");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        Label firstNamelbl = new Label("First Name:");
        TextField firstNameInput = new TextField(user.getCustFirstName());
        Label lastNamelbl = new Label("Last Name:");
        TextField lastNameInput = new TextField(user.getCustLastName());
        Label passwordlbl = new Label("Password:");
        PasswordField passwordInput = new PasswordField();
        Button saveButton = new Button("Save");

        oGridPane.add(firstNamelbl, 0, 0);
        oGridPane.add(firstNameInput, 1, 0);
        oGridPane.add(lastNamelbl, 0, 1);
        oGridPane.add(lastNameInput, 1, 1);
        oGridPane.add(passwordlbl, 0, 2);
        oGridPane.add(passwordInput, 1, 2);
        oGridPane.add(saveButton, 1, 3);

        saveButton.setOnAction(e -> {
            if (firstNameInput.getText().isEmpty() || lastNameInput.getText().isEmpty()) {
                Message("Validation Error", "First name and last name cannot be empty.");
                return;
            }

            user.setCustFirstName(firstNameInput.getText());
            user.setCustLastName(lastNameInput.getText());
            if (!passwordInput.getText().isEmpty()) {
                user.setCustPassword(passwordInput.getText());
            }
            Message("Profile Updated", "Your profile has been updated successfully.");
            getDashboard(user);
        });

        Scene editProfileScene = new Scene(oGridPane, 300, 200);
        ps.setScene(editProfileScene);
    }

    private void getPlaceOrder(User user) {
        ps.setTitle(user.CustisVIP() ? "Place VIP Order" : "Place Order");

        VBox ovbox = new VBox(10);
        ovbox.setPadding(new Insets(25, 25, 25, 25));
        ovbox.setAlignment(Pos.CENTER);

        Label menulbl = new Label("Menu:");
        ComboBox<FoodItem> foodComboBox = new ComboBox<>();
        foodComboBox.getItems().addAll(
                new FoodItem("Burrito", 7),
                new FoodItem("Fries", 4),
                new FoodItem("Soda", 2)
        );
        foodComboBox.getSelectionModel().selectFirst();

        HBox addItemBox = new HBox(10);
        TextField quantityInput = new TextField();
        quantityInput.setPromptText("Quantity");
        Button addItemButton = new Button("Add to Basket");
        addItemBox.getChildren().addAll(foodComboBox, quantityInput, addItemButton);
        addItemBox.setAlignment(Pos.CENTER);

        addItemButton.setOnAction(e -> {
            FoodItem selectedFood = foodComboBox.getValue();
            int quantity;
            try {
                quantity = Integer.parseInt(quantityInput.getText());
                if (quantity < 1) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                Message("Invalid Quantity", "Please enter a valid quantity.");
                return;
            }
            for (int i = 0; i < quantity; i++) {
                shoppingBasket.add(selectedFood);
            }
            updateBasketlbl(user);
        });

        Button proceedToPaymentButton = new Button("Proceed to Payment");
        Button backButton = new Button("Back");

        proceedToPaymentButton.setOnAction(e -> getPaymentForm(user));
        backButton.setOnAction(e -> getDashboard(user));

        ovbox.getChildren().addAll(menulbl, addItemBox, lblbasket, proceedToPaymentButton, backButton);

        Scene placeOrderScene = new Scene(ovbox, 400, 400);
        ps.setScene(placeOrderScene);
    }

    private void updateBasketlbl(User user) {
        StringBuilder sb = new StringBuilder("Shopping Basket:\n");
        for (FoodItem item : shoppingBasket) {
            sb.append(item.toString()).append("\n");
        }
        if (user.CustisVIP() && shoppingBasket.size() >= 3) {
            sb.append("VIP Discount: -$3.00\n");
        }
        lblbasket.setText(sb.toString());
    }

    private void getPaymentForm(User user) {
        ps.setTitle("Payment");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        double totalPrice = shoppingBasket.stream().mapToDouble(FoodItem::getFoodPrice).sum();
        if (user.CustisVIP() && shoppingBasket.size() >= 3) {
            totalPrice -= 3.00; // VIP discount of $3.00
        }

        Label totalPricelbl = new Label("Total Price: $" + totalPrice);
        Label cardNumberlbl = new Label("Card Number:");
        TextField cardNumberInput = new TextField();
        Label expiryDatelbl = new Label("Expiry Date:");
        TextField expiryDateInput = new TextField();
        Label cvvlbl = new Label("CVV:");
        TextField cvvInput = new TextField();
        Button confirmButton = new Button("Confirm Payment");

        oGridPane.add(totalPricelbl, 0, 0, 2, 1);
        oGridPane.add(cardNumberlbl, 0, 1);
        oGridPane.add(cardNumberInput, 1, 1);
        oGridPane.add(expiryDatelbl, 0, 2);
        oGridPane.add(expiryDateInput, 1, 2);
        oGridPane.add(cvvlbl, 0, 3);
        oGridPane.add(cvvInput, 1, 3);
        oGridPane.add(confirmButton, 1, 4);

        final double[] finalPrice = {totalPrice};
        confirmButton.setOnAction(e -> {
            if (cardNumberInput.getText().isEmpty() || expiryDateInput.getText().isEmpty() || cvvInput.getText().isEmpty()) {
                Message("Validation Error", "All payment fields are required.");
                return;
            }

            if (user.CustisVIP()) {
                int creditsToRedeem = getRedeemCreditsForm(user);
                finalPrice[0] -= creditsToRedeem / 100.0;
                user.CustaddCredits((int) (finalPrice[0] * 100));
            }

            // Handle payment validation and order confirmation
            Order order = new Order(new ArrayList<>(shoppingBasket), "await for collection", finalPrice[0]);
            ordersList.add(order);
            Message("Payment Successful", "Your order has been placed successfully.");
            shoppingBasket.clear();
            getDashboard(user);
        });

        Scene paymentScene = new Scene(oGridPane, 400, 300);
        ps.setScene(paymentScene);
    }

    private int getRedeemCreditsForm(User user) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Redeem Credits");
        dialog.setHeaderText("You have " + user.getCustCredits() + " credits.");
        dialog.setContentText("Enter credits to redeem:");

        int creditsToRedeem = 0;
        try {
            String result = dialog.showAndWait().orElse("");
            creditsToRedeem = Integer.parseInt(result);
            if (creditsToRedeem > user.getCustCredits()) {
                Message("Invalid Credits", "You do not have enough credits.");
                return 0;
            }
        } catch (NumberFormatException e) {
            Message("Invalid Input", "Please enter a valid number.");
        }

        return creditsToRedeem;
    }

    private void getViewOrders(User user) {
        ps.setTitle("View Orders");

        VBox ovbox = new VBox(10);
        ovbox.setPadding(new Insets(25, 25, 25, 25));
        ovbox.setAlignment(Pos.CENTER);

        Label ordersListlbl = new Label("Orders:");
        ovbox.getChildren().add(ordersListlbl);

        // Reverse the order of the ordersList list
        List<Order> reversedOrders = new ArrayList<>(ordersList);
        Collections.reverse(reversedOrders);

        for (Order order : reversedOrders) {
            String orderDetails = "Date: " + order.getFormattedDateTime() +
                    ", Total Price: $" + order.getOrderTotalPrice() +
                    ", Status: " + order.getOrderStatus() +
                    ", Collect Time: " + order.getFormattedCollectTime();
            Label orderlbl = new Label(orderDetails);
            Button collectButton = new Button("Collect");
            Button cancelButton = new Button("Cancel");

            if (order.getOrderStatus().equals("cancelled") || order.getOrderStatus().equals("collected")) {
                collectButton.setDisable(true);
                cancelButton.setDisable(true);
            } else {
                collectButton.setOnAction(e -> getCollectOrderForm(order, user));
                cancelButton.setOnAction(e -> {
                    order.setOrderStatus("cancelled");
                    getViewOrders(user);
                });
            }

            HBox orderBox = new HBox(10, orderlbl, collectButton, cancelButton);
            orderBox.setAlignment(Pos.CENTER);
            ovbox.getChildren().add(orderBox);
        }

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> getDashboard(user));
        ovbox.getChildren().add(backButton);

        Scene viewOrdersScene = new Scene(ovbox, 400, 400);
        ps.setScene(viewOrdersScene);
    }

    private void getCollectOrderForm(Order order, User user) {
        ps.setTitle("Collect Order");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        Label collectTimelbl = new Label("Collect Time (yyyy-MM-dd HH:mm:ss):");
        TextField collectTimeInput = new TextField();
        Button collectButton = new Button("Collect");
        Button backButton = new Button("Back");

        oGridPane.add(collectTimelbl, 0, 0);
        oGridPane.add(collectTimeInput, 1, 0);
        oGridPane.add(collectButton, 1, 1);
        oGridPane.add(backButton, 0, 1);

        collectButton.setOnAction(e -> {
            try {
                LocalDateTime collectTime = LocalDateTime.parse(collectTimeInput.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                if (collectTime.isAfter(order.getDateTime().plusMinutes(15))) {
                    order.setCollectTime(collectTime);
                    order.setOrderStatus("collected");
                    Message("Order Collected", "Order has been successfully collected.");
                    getViewOrders(user);
                } else {
                    Message("Invalid Time", "Collect time must be at least 15 minutes after the order was placed.");
                }
            } catch (Exception ex) {
                Message("Invalid Time", "Please enter a valid date and time in the format yyyy-MM-dd HH:mm:ss.");
            }
        });

        backButton.setOnAction(e -> getViewOrders(user));

        Scene collectOrderScene = new Scene(oGridPane, 400, 200);
        ps.setScene(collectOrderScene);
    }

    /*
    private void getExportOrders(User user) {
        ps.setTitle("Export Orders");

        VBox ovbox = new VBox(10);
        ovbox.setPadding(new Insets(25, 25, 25, 25));
        ovbox.setAlignment(Pos.CENTER);

        Label selectOrderslbl = new Label("Select Orders to Export:");
        ListView<Order> ordersListListView = new ListView<>();
        ordersListListView.getItems().addAll(ordersList);
        ordersListListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        CheckBox includeItemsCheckBox = new CheckBox("Include Ordered Items");
        CheckBox includePriceCheckBox = new CheckBox("Include Total Price");

        Button exportButton = new Button("Export");
        Button backButton = new Button("Back");

        exportButton.setOnAction(e -> {
            List<Order> selectedOrders = ordersListListView.getSelectionModel().getSelectedItems();
            if (selectedOrders.isEmpty()) {
                Message("Export Failed", "No ordersList selected for export.");
                return;
            }

            FileChooser fc = new FileChooser();
            fc.setTitle("Save Orders");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
            fc.setInitialFileName("ordersList.csv");
            File file = fc.showOpenDialog(ps);

            if (file != null) {
                exportOrdersToFile(selectedOrders, file, includeItemsCheckBox.isSelected(), includePriceCheckBox.isSelected());
            }
        });

        backButton.setOnAction(e -> getDashboard(user));

        ovbox.getChildren().addAll(selectOrderslbl, ordersListListView, includeItemsCheckBox, includePriceCheckBox, exportButton, backButton);

        Scene exportOrdersScene = new Scene(ovbox, 400, 400);
        ps.setScene(exportOrdersScene);
    }
*/
    
    private void getExportOrders(User user) {
    ps.setTitle("Export Orders");

    VBox ovbox = new VBox(10);
    ovbox.setPadding(new Insets(25, 25, 25, 25));
    ovbox.setAlignment(Pos.CENTER);

    Label selectOrderslbl = new Label("Select Orders to Export:");
    ListView<Order> ordersListListView = new ListView<>();
    ordersListListView.getItems().addAll(ordersList);
    ordersListListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    CheckBox includeItemsCheckBox = new CheckBox("Include Ordered Items");
    CheckBox includePriceCheckBox = new CheckBox("Include Total Price");

    Button exportButton = new Button("Export");
    Button backButton = new Button("Back");

    exportButton.setOnAction(e -> {
        List<Order> selectedOrders = ordersListListView.getSelectionModel().getSelectedItems();
        if (selectedOrders.isEmpty()) {
            Message("Export Failed", "No orders selected for export.");
            return;
        }

        FileChooser fc = new FileChooser();
        fc.setTitle("Save Orders");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        fc.setInitialFileName("orders.csv");
        File file = fc.showSaveDialog(ps);

        if (file != null) {
            exportOrdersToFile(selectedOrders, file, includeItemsCheckBox.isSelected(), includePriceCheckBox.isSelected());
        }
    });

    backButton.setOnAction(e -> getDashboard(user));

    ovbox.getChildren().addAll(selectOrderslbl, ordersListListView, includeItemsCheckBox, includePriceCheckBox, exportButton, backButton);

    Scene exportOrdersScene = new Scene(ovbox, 400, 400);
    ps.setScene(exportOrdersScene);
}

    private void exportOrdersToFile(List<Order> ordersList, File file, boolean includeItems, boolean includePrice) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("Date,Status,Collect Time");
            if (includeItems) {
                writer.write(",Ordered Items");
            }
            if (includePrice) {
                writer.write(",Total Price");
            }
            writer.newLine();

            for (Order order : ordersList) {
                writer.write(order.getFormattedDateTime() + "," + order.getOrderStatus() + "," + order.getFormattedCollectTime());
                if (includeItems) {
                    StringBuilder itemsString = new StringBuilder();
                    for (FoodItem item : order.getItems()) {
                        itemsString.append(item.getFoodName()).append(" (").append(item.getFoodPrice()).append("), ");
                    }
                    if (itemsString.length() > 0) {
                        itemsString.setLength(itemsString.length() - 2);
                    }
                    writer.write("," + itemsString.toString());
                }
                if (includePrice) {
                    writer.write("," + order.getOrderTotalPrice());
                }
                writer.newLine();
            }

            Message("Export Successful", "Orders have been exported successfully.");
        } catch (IOException e) {
            Message("Export Failed", "An error occurred while exporting ordersList: " + e.getMessage());
        }
    }

    private void getVIPUpgrade(User user) {
        ps.setTitle("Upgrade to VIP");

        GridPane oGridPane = new GridPane();
        oGridPane.setAlignment(Pos.CENTER);
        oGridPane.setHgap(10);
        oGridPane.setVgap(10);
        oGridPane.setPadding(new Insets(25, 25, 25, 25));

        Label emaillbl = new Label("Email:");
        TextField emailInput = new TextField();
        Button upgradeButton = new Button("Upgrade");

        oGridPane.add(emaillbl, 0, 0);
        oGridPane.add(emailInput, 1, 0);
        oGridPane.add(upgradeButton, 1, 1);

        upgradeButton.setOnAction(e -> {
            if (emailInput.getText().isEmpty() || !emailInput.getText().contains("@")) {
                Message("Validation Error", "Please enter a valid email address.");
                return;
            }

            user.CustupgradeToVIP(emailInput.getText());
            Message("VIP Upgrade", "You have been upgraded to VIP. Please log out and log in again to access VIP functionalities.");
            getLoginForm();
        });

        Scene vipUpgradeScene = new Scene(oGridPane, 300, 200);
        ps.setScene(vipUpgradeScene);
    }

  
    public static void main(String[] args) {
        launch(args);
    }
    
      private void Message(String title, String message) {
        Alert oalert = new Alert(Alert.AlertType.INFORMATION);
        oalert.setTitle(title);
        oalert.setHeaderText(null);
        oalert.setContentText(message);
        oalert.showAndWait();
    }

}
